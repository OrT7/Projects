
#ifndef UNTITLED1_INCLUDES_H
#define UNTITLED1_INCLUDES_H

//all the library that been used.

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>


#endif //UNTITLED1_INCLUDES_H
