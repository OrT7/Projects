#include "func.h"


char * suit_list[] = {"Spades","Hearts","Clubs","Diamonds"};    //Array of card suits, the index in the array is represented by the suit's value.
char * rank_list[] = {"Ace","2","3","4","5","6","7","8","9","10","Jack","Queen","King"};  //Array of card ranks, the index in the array is represented by the rank's value.


void card_set_suit(Card * card, int suit) {
    (card -> data) = (card -> data) | suit;
}

void card_set_rank(Card* card, uint8_t rank) {
    (card -> data) = (card -> data) | (rank << 2);
}

void checkGameStatus(int* gameFlag, GameStats* stats){
    if (*gameFlag==BlackJack){
        printf("\n*************\nYOU GOT BLACKJACK !!!\n*************\n");
        stats->cash+=2.5*stats->pot;
        stats->pot=0;
        *gameFlag=NoDraw;
    }

    if (*gameFlag==WIN){
        printf("\n*************\n YOU WIN !!! \n*************\n");
        stats->cash+=2*(stats->pot);
        stats->pot=0;
        *gameFlag= NoDraw;
    }

    if (*gameFlag==LOSE){
        printf("\n**************\n YOU LOSE !!! \n**************\n");
        stats->pot=0;
        *gameFlag= NoDraw;
    }

}

void dealerCheck(cardList* dealerHand,cardList* playerHand,int* flag,cardList* deck){
    printf("\nDealer's hand:\n");
    printList(dealerHand);
    while(handSum(dealerHand)<17&&handSum(dealerHand)< handSum(playerHand)){
        printf("\nDealer's hand:\n");
        draw_card(dealerHand,deck);
        printList(dealerHand);
    }
    if (handSum(dealerHand)>21||handSum(dealerHand)< handSum(playerHand)){
        if (handSum(dealerHand)>21)printf("\n**Dealer BUST**\n");
        *flag= WIN;
    } else {
        if (handSum(dealerHand) > handSum(playerHand)) {
            *flag = LOSE;
        }

        if (handSum(dealerHand) == handSum(playerHand)) {
            printf("\n**IT'S A TIE!**\n");
            *flag = DRAW;
        }
    }

}

int get_rank(Card *card){
    int value = (int)(card-> data >> 2)+1;
    if (value>10)value=10;
    return value;
}

void freeList(cardList* list) {
    Card *temp;
        while (list->head != NULL) {
            temp = list->head;
            list->head = list->head->next;
            free(temp);
        }
}

cardList* GameInitialization(){
    cardList * deck = NULL;
    deck = malloc(sizeof (*deck));
    if (deck == NULL) {
        printf("Failed to allocate memory for cardList\n");
    }
    Card *card = NULL;
    Card* ptr = NULL;
    for (int suit = 0; suit < SUITS ; suit++) {
        for (int rank = 0; rank < RANKS; rank++) {
            card = malloc(sizeof(*card));

            card -> next = NULL;
            card -> data = 0;
            card_set_suit(card, suit);
            card_set_rank(card, rank);

            if (deck->head == NULL) {
                deck -> head = card;
            } else {
                ptr -> next = card;
            }
            ptr = card;
            (deck -> len)++;
        }
    }
    return deck;
}

void playerCheck(int sum ,int* gameFlag){
    if (sum>21){
        *gameFlag=LOSE;
        printf("\n**Player BUST**\n");
    }
}

int handSum(cardList* list) {
    int sum = 0;
    int AceFlag = NoAce;
    Card* tmp = list -> head;
    while (tmp != NULL) {
        if (get_rank(tmp) == AceExist) {
            AceFlag = AceExist;
        }
        sum += get_rank(tmp);
        tmp= tmp->next;
    }
    if (AceFlag==AceExist&&sum+10<=21){
        sum=sum+10;
    }

    return sum;
}

void printList( cardList* list){
    Card* card = list -> head;
    while (card != NULL) {
        printf("* %s of %s \n", rank_list[card->data >> 2], suit_list[card->data & 3]);
        card = card->next;
    }
    printf("\n-------------------\n");
    printf("***  Sum is %2d  ***",handSum(list));
    printf("\n-------------------\n");
}

void draw_card(cardList* list, cardList *deck) {

    unsigned index = rand() % (deck->len);
    Card *card = deck -> head; //card is a ptr to the head of the deck
    Card *preCard = deck -> head;
    if (index == 0) {
        deck -> head = deck -> head -> next;
    } else if(index==1){
        card =deck->head->next;
        preCard -> next = card -> next;
    }

    else {
        while (1 < index) {
            preCard = card;
            card = card->next;
            index--;
        }//card is ptr to random card
        preCard -> next = card -> next;
    }
    deck -> len--;
    card -> next = NULL;

    Card* ptr = list->head;
    list->head = card;
    card->next = ptr;
    list -> len++;
}

void new_game(GameStats *stats){
    stats->cash = initialCash;
    stats->pot= initialPot;
    stats->dealer_hand =NULL;
    stats->dealer_hand = malloc(sizeof (*stats->dealer_hand));
    stats->player_hand=NULL;
    stats->player_hand = malloc(sizeof (*stats->player_hand));

    printf("\nWelcome to BlackJack!");
}

void betting(int* flag, GameStats *stats, cardList* deck) {

    int bet;
    printf("please place your bet, your bet have to be a multiply of 10: \n");
    scanf("%d", &bet);
    while (getchar() != '\n');
    while (bet % 10 != 0 || (*flag == NoDraw && bet == 0) || stats->cash - bet < 0||bet<0) {
        printf("your bet of %d is not legal please try again\n", bet);
        if (stats->cash - bet<0)printf("You don't have enough cash\n");
        else if (bet % 10 != 0)printf("Your bet is not a multiply of 10\n");
        scanf("%d", &bet);
        while (getchar() != '\n');
    }
    *flag=NoDraw;
    stats->cash = stats->cash - bet;
    stats->pot += bet;

    draw_card(stats->player_hand, deck);
    draw_card(stats->dealer_hand, deck);
    draw_card(stats->player_hand, deck);
    draw_card(stats->dealer_hand, deck);

    printf("\n\nDealer's hand:\n\n");
    printf("%s of %s", rank_list[stats->dealer_hand->head->data >> 2], suit_list[stats->dealer_hand->head->data & 3]);
    printf("\n?????");
    printf("\n\nYour hand:\n\n");
    printList(stats->player_hand);
}

void returnToDeck(cardList* list, cardList* deck){
    Card * temp;
    while (list->head!=NULL) {
        temp = list->head;
        list->head = list->head->next;
        temp->next = deck->head;
        deck->head = temp;
        deck->len++;
        list->len--;
    }
}





