

#ifndef UNTITLED1_FUNC_H
#define UNTITLED1_FUNC_H

#include "includes.h"

//Card Related
#define SUITS 4  //number of suit's types
#define RANKS 13 //number of rank's types

//GameFlag Related
#define NoDraw 0 // Represent NewRound in the gameFlag
#define LOSE -1 // Represent Lose in the gameFlag
#define DRAW 1 // Represent Draw in the gameFlag
#define WIN 2 // Represent Win in the gameFlag
#define BlackJack 3 // Represent a BlackJack in the gameFlag

//Ace Rule Related
#define NoAce 0 // Flag that there is No-Ace in the hand
#define AceExist 1 // Flag that there is an Ace-Exist in the hand

//Initial cash
#define initialCash 1000
#define initialPot 0

//Array of card, Suit and Rank.
char * suit_list[];
char * rank_list[];


//Struct that been used:

//struct of card , contain the data in 8 bits which composed by the first 2 bits => which represents the suit , and the 2 to 6 bits => that represents the rank.
typedef struct Card{
    uint8_t data;
    struct Card* next;
}Card;

//struct of cardList, use as the: Deck, player's Hand , Dealer's Hand. => linked list of cards.

typedef struct cardList {
    Card * head; // head is a pointer to the top card in the list.
    size_t len; // the amount of cards in the list.
}cardList;

//Struct that contain data member that manage the game
typedef struct GameStats{
    cardList* dealer_hand; //The list of cards in the Dealer's hand.
    cardList* player_hand; //The list of cards in the Dealer's hand.
    int cash; //Keep track on the amount of cash the player has.
    int pot; //Keep track on the amount of cash in the pot.
}GameStats;


//Use to set up the suit of a card using bitwise operation to accesses the two LSB bits that represent the suit type.
void card_set_suit(Card * card, int suit);

//Use to set up the rank of a card using bitwise operation to accesses the bits 2 to 5, that represent the rank of the card.
void card_set_rank(Card* card, uint8_t rank);

//At the end of each round checkGameStatus will check if the player win, lose or wins by BlackJack and print a massage accordingly.
//checkGameStatus will also update the player's cash and pot accordingly.
void checkGameStatus(int* gameFlag, GameStats* stats);

//dealerCheck will manage the all Dealer's turn, the function will call printList to print the Dealer's hand.
//it will call Draw card to add cards to the dealer's hand according to the rules of the game
//at the end of the drawing phase, dealerCheck will determine if the player win,draw, lose or wins by BlackJack and will update the gameFlag accordingly.
void dealerCheck(cardList* dealerHand,cardList* playerHand,int* flag,cardList* deck);

//At the end of the program freeList will free the allocated memory of the dynamic objects in the linked list.
void freeList(cardList* list);

//get_rank will return the True value of a card, using bitwise operation to accesses the bits 2 to 5 that contain the value.
//get_rank will also convert Jack, Queen and King to 10 values according to the rules of the game
int get_rank(Card *card);

//GameInitialization allocate the deck cardList and allocate each card in the 52 cards in the game.
//GameInitialization also set up the card data and suit using 2 for loop that set up 4 suit of each card.
//it returns the list it's created.
cardList* GameInitialization();

//printList print all the cards in the list.
void printList( cardList* list);

//check if the player is bust, by checking if he has more than 21 points in cards value, if so update the gameFlag to LOSE.
void playerCheck(int sum, int* flag);

//return the sum all the card's value in the list.
int handSum(cardList* list);

//pick a random card in the desk and place it in the list, use rand() % (deck->len) to pick a card in a location relative to the remaining deck size.
//Then it place that card on top of the list and also connect the previous card in the deck to the next one.
void draw_card(cardList* list, cardList* deck);

//new_game set up the GameStats data member, set the pot and the cash to the initialCash and initialPot, and allocate the player's hand list and the dealer's hand list.
void new_game(GameStats *stats);

//manage the betting phase, set the amount of betting the pot and player's cash, call drawCard to draw the first two card,also print the dealer hand with the second card as '????'
void betting(int* flag, GameStats *stats, cardList* deck);

//return all the card from a list to the head of the deck.
void returnToDeck(cardList* list, cardList* deck);


#endif //UNTITLED1_FUNC_H
