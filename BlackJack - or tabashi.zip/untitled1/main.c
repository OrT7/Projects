//Created by OR TABASHI
//ID 206022675


#include "includes.h"
#include "func.h"

int main() {

    srand(time(0));
    //new game session
    cardList* deck = GameInitialization();
    GameStats stats;
    new_game(&stats);
    int gameFlag =NoDraw;
    char choice[6];
    //round loop
    char another_round = 'y';
    while (another_round == 'y'){
        printf("\n\nyour cash is: %d\nthe current pot is %d\n\n",stats.cash,stats.pot);
        betting(&gameFlag,&stats, deck);

        if (handSum(stats.player_hand)==21)gameFlag=BlackJack;

        while(strcmp(choice,"stand")!=0&&gameFlag!=LOSE&&gameFlag!=BlackJack){
            printf("\n\nWrite 'hit' or 'stand',make your decision:");
            scanf("%s", choice);
            while (getchar() != '\n');

            if (strcmp(choice,"hit")==0){
                draw_card(stats.player_hand, deck);
                printList(stats.player_hand);
                playerCheck(handSum(stats.player_hand),&gameFlag);
            }
        }

        if (gameFlag != LOSE && gameFlag!=BlackJack) {
            dealerCheck(stats.dealer_hand,stats.player_hand ,&gameFlag, deck);
        }
        checkGameStatus(&gameFlag,&stats);

        printf("\nthis round is over\nyour current cash: %d\nThe current pot is: %d\n\ndo you want to play again y/n \n",stats.cash,stats.pot);
        another_round= getchar();
        while (getchar() != '\n');
        if (another_round == 'y'){
            choice[0] ='\0';
            if (stats.cash<10){
                printf("\nOh no, You are **OUT OF CASH**\n\nPlease come back with more, and have a nice day :)\n\nThanks for playing BlackJack!");
                exit(0);
            }
            returnToDeck(stats.player_hand,deck);
            returnToDeck(stats.dealer_hand,deck);
        }

    }

    //exit the game
    if (gameFlag==DRAW)stats.cash+=stats.pot;
    printf("\n\nThanks for playing BlackJack!\nYour cash is: %d",stats.cash);
    freeList(stats.player_hand);
    freeList(stats.dealer_hand);
    freeList(deck);
    free(deck);
    free(stats.player_hand);
    free(stats.dealer_hand);

    return 0;
}
 