//
// Created by or tabashi on 22/09/2022.
//
#pragma once
#ifndef BLACKJACK_INCLUDES_H
#define BLACKJACK_INCLUDES_H

#endif //BLACKJACK_INCLUDES_H
#include "main.c"
#include "structs.c"
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>
#include "GameInitialization.c"
