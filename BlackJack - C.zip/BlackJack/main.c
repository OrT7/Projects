#include "includes.h"





int main( )
{
    cardList* deck = GameInitialization();
    int i = 100;
    while (i){
        printf("%d\n",deck->len);
    }
    return 0;
}
