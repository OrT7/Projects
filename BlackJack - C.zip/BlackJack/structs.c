#pragma once
#include "includes.h"


#define SUITS 4  //number of suit's types
#define RANKS 13 //number of rank's types

char * suit_list = {"Spades","Hearts","Clubs","Diamonds"};    //Array of card suits, the index in the array is represented by the suit's value.
char * value_list = {"Ace","1","2","3","4","5","6","7","8","9","10","Jack","Queen","King"};  //Array of card ranks, the index in the array is represented by the rank's value.

//struct of card , contain the data in 8 bits which composed by the first 2 bits => which represents the suit , and the 2 to 6 bits => that represents the rank.
typedef struct Card{
    uint8_t data;
    struct Card* next;
}Card;

//struct of cardList, use as the desk => linked list of cards.

typedef struct cardList {
    Card * head; // head is a pointer to the top card in the deck.
    int len; // the amount of cards that remained in the deck (the length of the deck link list)
}cardList;

typedef struct GameStats{
    cardList* dealer_hand;
    cardList* player_hand;
    int cash;
    int pot;
}GameStats;