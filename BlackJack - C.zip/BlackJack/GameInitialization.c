


void card_set_suit(Card * card, int suit) {
    (card -> data) = (card -> data) | suit;
}
void card_set_rank(Card* card, uint8_t rank) {
    (card -> data) = (card -> data) | (rank << 2);
}
cardList* GameInitialization(){
    cardList * deck = NULL;
    deck = malloc(sizeof (*deck));
    if (deck == NULL) {
        printf("Failed to allocate memory for cardList\n");
    }
    Card *card = NULL;
    Card* ptr = NULL;
    for (int suit = 0; suit < SUITS ; suit++) {
        for (int rank = 0; rank < RANKS; rank++) {
            card = malloc(sizeof(*card));

            card -> next = NULL;
            card -> data = 0;
            card_set_suit(card, suit);
            card_set_rank(card, rank);

            if (deck->head == NULL) {
                deck -> head = card;
            } else {
                ptr -> next = card;
            }
            ptr = card;
            deck -> len++;
        }
    }
    return deck;
}
