

#include <arpa/inet.h>
#include <netinet/in.h>
#include <inttypes.h>
#include <sys/socket.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#define BUF_SIZE 60
#define IP_ADDRESS "192.168.1.1"
#define FLAG_ZERO 0
#define TRUE 1
#define PORT 7
#define LEN 30
#define SLEEP_TIME 3
#define ERROR -1
#define EXIT 0

typedef struct reply //use to save the return packet detail
{
    uint32_t id;
    uint8_t status;
} reply;
typedef struct sent //use to save the sent packet detail
{
    uint32_t id;
    uint8_t peri;
    uint8_t iter;
    uint8_t size;
    char *msg;
} sent;

int main()
{
    /*************************************** Vars ***************************************************/
    struct sockaddr_in dest; // Holds Destination socket (IP+PORT)
    int socket_fd;           // Holds socket file descriptor
    unsigned int ssize;      // Holds size of dest
    char buf[BUF_SIZE + 1];  // Used for writing/ Reading from buffer
    int retVal = 0;          // Holds return Value for recvfrom() / sendto()
    reply resv;             // Holds the return values of id and test status
    sent test;              // Holds values of the packet that sent to the test unit , use to Initialize the buffer
    int choice=1;           // the periphery that the user would like to check
    int idIndex=1;           // use to index the test id,

    /************************************* Initialization ******************************************/

    socket_fd = socket(AF_INET, SOCK_DGRAM, FLAG_ZERO); // Create socket
    if (socket_fd == ERROR)
    {
        perror("Create socket");
        exit(TRUE);
    } // Validate the socket

    bzero((char *)&dest, sizeof(dest));           // Clearing the struct
    dest.sin_family = (short)AF_INET;             // Setting IPv4
    dest.sin_port = htons(PORT);                  // Setting port
    dest.sin_addr.s_addr = inet_addr(IP_ADDRESS); // Setting IP address


    ssize = sizeof(dest); // Get dest size

    /************************************* Code *****************************************************/
    while (choice!=EXIT) //run as long as the user did not choose to exit
    {
        printf("Please select a test:\n1)Timer\n2)UART\n3)SPI\n4)I2C\n5)ADC\n0)Exit\n");
        scanf("%d",&choice);
        while (getchar() != '\n');
        while (choice<0||5<choice){
            printf("The test you selected is invalid!\n");
            printf("Please select a test:\n1)Timer\n2)UART\n3)SPI\n4)I2C\n5)ADC\n0)Exit\n");
            scanf("%d",&choice);
            while (getchar() != '\n');
        }//ask form the user a periphery to check
        if (choice==EXIT){
            printf("goodbye :)");
            exit(0);
        }

        /************************************* init test *****************************************************/
        test.id = idIndex; //set the test id
        idIndex++; //increment test id index
        test.peri = choice; // set periphery according to the user choice
        test.iter = 7; // set number of iteration
        test.msg ="hello"; //set pattern , must be smaller than 256 chars
        if (strlen(test.msg)<1||strlen(test.msg)>255){
            printf("\nError test pattern must be bigger then 0 and smaller than 256 chars\n");
            exit(1);
        }
        test.size = strlen(test.msg);//set pattern size
        /*************************************** buffer loading ************************************************/


        *(uint32_t *)(buf + 0) = test.id;
        *(uint8_t *)(buf + 4) = test.peri;
        *(uint8_t *)(buf + 5) = test.iter;
        *(uint8_t *)(buf + 6) = test.size;
        memcpy(buf + 7,test.msg, test.size);

        /*************************************** sending the packet **********************************************/

        retVal = sendto(socket_fd, buf, LEN, FLAG_ZERO, (struct sockaddr *)&dest, ssize); // Send Ping
        if (retVal < 0)
            break;
        if (strcmp(buf, "exit") == FLAG_ZERO)
            break;
        /*************************************** receiving the packet **********************************************/
        if (strcmp(buf, "good") == FLAG_ZERO)
        {
            retVal = recvfrom(socket_fd, buf, LEN, FLAG_ZERO, (struct sockaddr *)&dest, &ssize); // Get answer
            if (retVal < 0)
                break;
            if (strcmp(buf, "exit") == FLAG_ZERO)
                break;
        }
        else
        {
            retVal = recvfrom(socket_fd, buf, LEN, FLAG_ZERO, (struct sockaddr *)&dest, &ssize); // Get answer
            if (retVal < 0)
                break;
            if (strcmp(buf, "exit") == FLAG_ZERO)
                break;
            resv.status = *(uint8_t *)(buf +0); //set test status
            resv.id = *(uint32_t *)(buf + 1); //set the test id that return

            if (resv.status==1) { //checking the test status
                printf("Test %d: Successes\n", resv.id);
            } else{
                printf("Test %d: fail\n", resv.id);
            }
        }
    }

    close(socket_fd); // Closing socket
    printf("Closing client...\n");
    sleep(SLEEP_TIME);
    return 0;
}
