
#include "AdcProject.h"

void AdcProject(uint* statusFlag){
//start adc sampling with interrupt
	HAL_ADC_Start_IT(ADC_1);
	//get value from adc sample
	uint32_t Voltage = HAL_ADC_GetValue(ADC_1);
	//if value from adc sample are in correct range return true else return false
	if(MinVoltage<Voltage&&Voltage<MaxVoltage){
		*statusFlag = Success;
	}else{
		*statusFlag = Fail;
	}

}
