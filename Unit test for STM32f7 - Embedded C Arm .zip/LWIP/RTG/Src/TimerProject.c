
#include "TimerProject.h"

void TimerProject(uint* statusFlag){

	int secondFlag=-1;
	uint32_t count=0;

//start clock with interrupt
		HAL_TIM_Base_Start_IT(TIM_2);

//count each clock pulse, rise a secondFlag after a second according to pulse rate, if max pulse count exceed reset secondFlag
		void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim){
			 count++;
			 if(count==PulsePerSec){
				 secondFlag=true;
			 }
			 if(count>MaxPulsePerSec){
				secondFlag=false;
						 }
		 }

//each period elapsed is one second, check each second if secondFlag is on
	void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
		  if(secondFlag==true){
				*statusFlag = Success;
				count=RESET;
			}else{
				*statusFlag = Fail;
			}
	}

	HAL_Delay(1200); //wait 1.2 second,to allow the interrupt count check , and then check statusFlag
	if(secondFlag==-1){
		*statusFlag = Fail;
	}
}



