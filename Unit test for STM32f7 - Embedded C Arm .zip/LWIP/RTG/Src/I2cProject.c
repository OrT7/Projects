
#include "I2cProject.h"



void I2cProject(uint* statusFlag ,packets *packet){

	//initialize buffers and slave address
	uint16_t slaveAddress=2;
	uint8_t buffer_i2c1[MaxBuffer] = {0};
	uint8_t buffer_i2c2[MaxBuffer] = {0};

	//transmit from the master to slave
	I2cTransmitMaster(i2c1, i2c2,slaveAddress,packet->msg,buffer_i2c2, packet->size);

	//transmit from the slave to master
	I2cTransmitSlave(i2c1, i2c2, slaveAddress,buffer_i2c2,buffer_i2c1, packet->size);

	//compare the pattern from the packet to the i2c buffer
	if(strcmp(packet->msg, buffer_i2c1)==Match){
		*statusFlag = Success;
	}else{
		*statusFlag = Fail;
	}
}


void I2cTransmitMaster(UART_HandleTypeDef* master,UART_HandleTypeDef* slave,uint16_t slaveAddress,uint8_t* data,uint8_t* buffer,uint size){
	HAL_I2C_Slave_Receive_DMA(slave, buffer, size); //ready slave buffer to receive data
	HAL_I2C_Master_Transmit_DMA(master, slaveAddress, data, size);//transfer data from master to slave
	HAL_Delay(10);
}


void I2cTransmitSlave(UART_HandleTypeDef* master,UART_HandleTypeDef* slave,uint16_t slaveAddress,uint8_t* data,uint8_t* buffer,uint size){
	HAL_I2C_Master_Receive_DMA(master, slaveAddress, buffer, size); //ready master buffer to receive data
	HAL_I2C_Slave_Transmit_DMA(slave, data, size);////transfer data from slave to master
	HAL_Delay(10);
}


