
#include "SpiProject.h"


void SpiProgram(uint* statusFlag ,packets *packet){

	//initialize buffers
	uint8_t bufferMaster[MaxBuffer] = {0};
	uint8_t bufferSlave[MaxBuffer] = {0};

	//transmit from the master to slave
	HAL_SPI_Receive_DMA(SPI_5, bufferSlave, packet->size);
	HAL_SPI_Transmit(SPI_1, packet->msg, packet->size,TimeOut);
	HAL_Delay(10);

	//transmit from the slave to master
	HAL_SPI_Receive_DMA(SPI_1, bufferMaster, packet->size);
	HAL_SPI_Transmit(SPI_5, bufferSlave, packet->size,TimeOut);
	HAL_Delay(10);
	HAL_SPI_Receive_DMA(SPI_1, bufferMaster, packet->size);

	//compare the pattern from the packet to the spi buffer
	if(strcmp(packet->msg, bufferSlave)==Match){
		*statusFlag = Success;
	}else{
		*statusFlag = Fail;
	}

}






