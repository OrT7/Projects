
#include "UartProject.h"


void UartProject(uint* statusFlag ,packets *packet){

	//initialize buffers
	uint8_t buffer_uart4[MaxBuffer] = {0};
	uint8_t buffer_uart6[MaxBuffer] = {0};

	//transmit data by UART
	UartTransmit(&huart4, &huart6, packet->msg, buffer_uart6, packet->size);
	//transmit data by UART
	UartTransmit(UART_6, &huart4,packet->msg, buffer_uart4, packet->size);

	if(strcmp(packet->msg, buffer_uart4)==Match){
		*statusFlag = Success;
	}else{
		*statusFlag = Fail;
	}

}
void UartTransmit(UART_HandleTypeDef* source,UART_HandleTypeDef* destination,uint8_t* data,uint8_t* buffer,uint size){


	HAL_UART_Receive_DMA(destination, buffer, size);//ready buffer to receive data
	HAL_UART_Transmit_DMA(source, data, size); //transmit data
	HAL_Delay(10);
}



