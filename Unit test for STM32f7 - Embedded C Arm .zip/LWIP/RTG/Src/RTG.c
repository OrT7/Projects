#include "RTG.h"
/*
 *	transmit and receive packets using the LWIP.
 *	EVB configuration:
 *	IP: 		192.168.1.1
 *	NETMASK: 	255.255.255.0 (or 0.0.0.0/24)
 *	GATEWAY: 	192.168.1.100 (not in use but required by IDE)
 *	Port:		7
 */

///defines the cases of the peripherals, used by the switch case to choose which peripheral to active
#define TimerSelect 1
#define UartSelect 2
#define SpiSelect 3
#define I2cSelect 4
#define AdcSelect 5

void rtg_main() {

	udpServer_init();					//UDP server initialization
	while (1) {
		ethernetif_input(&gnetif);		//Handles the actual reception of bytes from the network interface
		sys_check_timeouts();			//Handle which checks timeout expiration
	}
}

bool test(packets *packet){
	uint statusFlag = Success;
	uint choise = packet->peri;

	while(packet->iter-- && statusFlag!=Fail){
		printf("\niter number %d\r\n",packet->iter);

			switch(choise){

			case TimerSelect:
			///Test Clock
				TimerProject(&statusFlag);
				break;
			case UartSelect:
			///UART
				UartProject(&statusFlag,packet);
			break;

			case SpiSelect:
			///SPI
				SpiProgram(&statusFlag,packet);
			break;

			case I2cSelect:
			///I2C
				I2cProject(&statusFlag,packet);
			break;


			case AdcSelect:
			///ADC
				AdcProject(&statusFlag);
			break;
			}
		}

	return statusFlag;
}
