#ifndef INC_AdcProject_H_
#define INC_AdcProject_H_

#include "RTG.h"

extern ADC_HandleTypeDef hadc1;
#define ADC_1 &hadc1
#define MinVoltage 3200
#define MaxVoltage 4200

void AdcProject(uint* statusFlag);
#endif /* INC_I2cProject_H_ */
