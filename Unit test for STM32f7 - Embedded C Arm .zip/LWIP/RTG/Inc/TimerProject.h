

#ifndef INC_CLOCKPROJECT_C_
#define INC_CLOCKPROJECT_C_

#include "RTG.h"

extern TIM_HandleTypeDef htim2;	//Change to match your UART number
#define TIM_2 &htim2				//Change to match your Timer number
#define PulsePerSec 216000000
#define MaxPulsePerSec 216100000

void TimerProject(uint* statusFlag);


#endif /* INC_CLOCKPROJECT_C_ */
