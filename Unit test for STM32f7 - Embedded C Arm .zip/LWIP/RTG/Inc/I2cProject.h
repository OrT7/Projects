#ifndef INC_I2cProject_H_
#define INC_I2cProject_H_
#include "RTG.h"

extern UART_HandleTypeDef hi2c1;		//Change to match your UART number
extern UART_HandleTypeDef hi2c2;
#define i2c1 &hi2c1
#define i2c2 &hi2c2


void I2cProject(uint* statusFlag,packets *packet);
void I2cTransmitMaster(UART_HandleTypeDef* master,UART_HandleTypeDef* slave,uint16_t slaveAddress,uint8_t* data,uint8_t* buffer,uint size);
void I2cTransmitSlave(UART_HandleTypeDef* master,UART_HandleTypeDef* slave,uint16_t slaveAddress,uint8_t* data,uint8_t* buffer,uint size);
#endif /* INC_I2cProject_H_ */
