#ifndef INC_SpiProject_H_
#define INC_SpiProject_H_

#include "RTG.h"

extern UART_HandleTypeDef hspi1;		//Change to match your UART number
extern UART_HandleTypeDef hspi5;		//Change to match your UART number
#define SPI_1 &hspi1					//Change to match your UART number
#define SPI_5 &hspi5					//Change to match your UART number
#define TimeOut 100

void SpiProgram(uint* statusFlag ,packets *packet);


#endif /* INC_SpiProject_H_ */
