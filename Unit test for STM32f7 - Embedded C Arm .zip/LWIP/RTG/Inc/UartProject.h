#ifndef INC_UartProject_H_
#define INC_UartProject_H_

#include "RTG.h"

extern UART_HandleTypeDef huart6;	//Change to match your UART number
extern UART_HandleTypeDef huart4;
#define UART_6 &huart6
#define UART_4 &huart4

void UartProject(uint* statusFlag,packets *packet);
void UartTransmit(UART_HandleTypeDef* source,UART_HandleTypeDef* destination,uint8_t* data,uint8_t* buffer,uint size);
#endif /* INC_UartProject_H_ */
